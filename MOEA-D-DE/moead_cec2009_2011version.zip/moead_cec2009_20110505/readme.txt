1. run moea_cpp/moea_cpp to get the data files (in POF folder).

2. run Matlab script result/sta.m to get the statistical results which are saved in tabs.txt. (a more readable table is in tabs.xls) 